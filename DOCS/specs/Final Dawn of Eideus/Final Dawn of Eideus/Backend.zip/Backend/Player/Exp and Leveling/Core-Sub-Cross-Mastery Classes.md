give me this list 

{
  "T1-war": {
    "M1-str/str": {
      "E1": { "affinity": "str" },
      "E2": { "affinity": "dex" },
      "E3": { "affinity": "int" },
      "E4": { "affinity": "str" },
      "E5": { "affinity": "dex" },
      "E6": { "affinity": "int" },
      "E7": { "affinity": null }
    },
    "M2-str/int": {
      "E1": { "affinity": "int" },
      "E2": { "affinity": "dex" },
      "E3": { "affinity": "str" },
      "E4": { "affinity": "int" },
      "E5": { "affinity": "dex" },
      "E6": { "affinity": "str" },
      "E7": { "affinity": null }
    },
    "M3-str/dex": {
      "E1": { "affinity": "str" },
      "E2": { "affinity": "int" },
      "E3": { "affinity": "dex" },
      "E4": { "affinity": "str" },
      "E5": { "affinity": "int" },
      "E6": { "affinity": "dex" },
      "E7": { "affinity": null }
    }
  },
  "T2-mage": {
    "M1-int/str": {
      "E1": { "affinity": "int" },
      "E2": { "affinity": "dex" },
      "E3": { "affinity": "str" },
      "E4": { "affinity": "int" },
      "E5": { "affinity": "dex" },
      "E6": { "affinity": "str" },
      "E7": { "affinity": null }
    },
    "M2-int/int": {
      "E1": { "affinity": "int" },
      "E2": { "affinity": "str" },
      "E3": { "affinity": "dex" },
      "E4": { "affinity": "int" },
      "E5": { "affinity": "str" },
      "E6": { "affinity": "dex" },
      "E7": { "affinity": null }
    },
    "M3-int/dex": {
      "E1": { "affinity": "dex" },
      "E2": { "affinity": "str" },
      "E3": { "affinity": "int" },
      "E4": { "affinity": "dex" },
      "E5": { "affinity": "str" },
      "E6": { "affinity": "int" },
      "E7": { "affinity": null }
    }
  },
  "T3-rogue": {
    "M1-dex/str": {
      "E1": { "affinity": "dex" },
      "E2": { "affinity": "int" },
      "E3": { "affinity": "str" },
      "E4": { "affinity": "dex" },
      "E5": { "affinity": "int" },
      "E6": { "affinity": "str" },
      "E7": { "affinity": null }
    },
    "M2-dex/int": {
      "E1": { "affinity": "dex" },
      "E2": { "affinity": "int" },
      "E3": { "affinity": "str" },
      "E4": { "affinity": "dex" },
      "E5": { "affinity": "int" },
      "E6": { "affinity": "str" },
      "E7": { "affinity": null }
    },
    "M3-dex/dex": {
      "E1": { "affinity": "dex" },
      "E2": { "affinity": "int" },
      "E3": { "affinity": "str" },
      "E4": { "affinity": "dex" },
      "E5": { "affinity": "int" },
      "E6": { "affinity": "str" },
      "E7": { "affinity": null }
    }
  }
}


- `str` vs `str` = **+1** ; `str` vs `dex` = **0** ; `str` vs `int` = **-1**
    
- `dex` vs `str` = **-1** ; `dex` vs `dex` = **+1** ; `dex` vs `int` = **0**
    
- `int` vs `str` = **0** ; `int` vs `dex` = **-1** ; `int` vs `int` = +1

filled with these names
A. Rebel- Disgruntled citizen looking to make some changes
B. Acolyte- an augment seeking induction into the ranks of the Church of the Ascension
C. Hacker- A systems specialist who gets off on the fact no doors are going to hold their secrets long if they want to peek inside

Sub-Classes
A. Rebel Subs
	1. Merc - A freelance Rebel fighter for hire. Set out for fame and fortune
	2. Specialist - A highly specialized Rebel fighter who has settled into a niche slot on a team of Rebel insurgents
	3. Recruit- A prospect rebel for an unnamed insurgency ring that has been recruited for special assignments
	
B. Acolyte Subs
	1. Convert - An Acolyte that has been initiated into the technocracy's Church of Ascension
	2. Priest - A lifelong member of the Church of Ascension who has progressed through the ranks to achieve the title of a Priest
	3. Parishioner - A valuable preferential member of the flock of the Church of Ascension
	
 C. Hacker Subs
	 1. Insurgent- A specialized tech support agent for the local insurgency. 
	 2. Zealot - An extremely passionate Hacker who is more extremist than insurgent. Has their own agenda although will partner up if it aligns with the current goals
	 3. Cipher - An encryption expert who works for the bureaucracy. A "good guy" by their own estimation and would be considered an ethical hacker.
	 
Cross Classes
A. 
	1. Soldier of Fortune- A famous well paid eagerly sought after mercenary rebel
    2. False Prophet - An apostate priest from the church of ascension who has been branded a false prophet by the leadership
	3.  Sleeper Cell- a Rebel/Recruit who has now earned enough trust and progressed far enough in their training to become a Sleeper Cell
	
B. 
	 4. The Un-made - a disillusioned rebel warrior turned acolyte for the Church of Ascension. An un-made has rejected his duty to the church and been excommunicated from the flocks of the augmented. Doomed to wandering the universe alone without the significant benefits the church offers to those who submit and spread the message of transhumanistic enlightenment. 
	 5. True Believer - An Acolyte of the Church of Ascension who became a priest. Serving the church faithfully has now become a senior member and donned the status of a True Believer
	 6. Cyber Heretic - A hacker turned acolyte who, after many years of faithful service, has had a falling out with the church over reasons now only known to them and has been labeled a Cyber Heretic by the Church of Ascension and a bounty placed on their heads. 
	 
C. 
     1. Hacktivist- A very political and bold hacker who loves rally's and protests and the occasional destruction of corporate property. 
     2.  Null Apostle- A high ranker member of the church of ascension who has been isolated from the flock and tasked with monitoring the congregations for the leadership. A covert surveillance and operations expert
     3.  Cryptocrat - A hacker who was recruited by the "9" The elite group of star system cartel overlords who has been targeted for assimilation into the army of the Prophet one of 3 leaders of the self proclaimed "Free Galaxies" and a pure AI construct. Although nine of the 3 or the 9 have revealed this to the citizens of the Free Galaxies. 