{
  "T1-war": {
    "M1-str/str": {
      "E1": { "affinity": "str" },
      "E2": { "affinity": "dex" },
      "E3": { "affinity": "int" },
      "E4": { "affinity": "str" },
      "E5": { "affinity": "dex" },
      "E6": { "affinity": "int" },
      "E7": { "affinity": null }
    },
    "M2-str/int": {
      "E1": { "affinity": "int" },
      "E2": { "affinity": "dex" },
      "E3": { "affinity": "str" },
      "E4": { "affinity": "int" },
      "E5": { "affinity": "dex" },
      "E6": { "affinity": "str" },
      "E7": { "affinity": null }
    },
    "M3-str/dex": {
      "E1": { "affinity": "str" },
      "E2": { "affinity": "int" },
      "E3": { "affinity": "dex" },
      "E4": { "affinity": "str" },
      "E5": { "affinity": "int" },
      "E6": { "affinity": "dex" },
      "E7": { "affinity": null }
    }
  },
  "T2-mage": {
    "M1-int/str": {
      "E1": { "affinity": "int" },
      "E2": { "affinity": "dex" },
      "E3": { "affinity": "str" },
      "E4": { "affinity": "int" },
      "E5": { "affinity": "dex" },
      "E6": { "affinity": "str" },
      "E7": { "affinity": null }
    },
    "M2-int/int": {
      "E1": { "affinity": "int" },
      "E2": { "affinity": "str" },
      "E3": { "affinity": "dex" },
      "E4": { "affinity": "int" },
      "E5": { "affinity": "str" },
      "E6": { "affinity": "dex" },
      "E7": { "affinity": null }
    },
    "M3-int/dex": {
      "E1": { "affinity": "dex" },
      "E2": { "affinity": "str" },
      "E3": { "affinity": "int" },
      "E4": { "affinity": "dex" },
      "E5": { "affinity": "str" },
      "E6": { "affinity": "int" },
      "E7": { "affinity": null }
    }
  },
  "T3-rogue": {
    "M1-dex/str": {
      "E1": { "affinity": "dex" },
      "E2": { "affinity": "int" },
      "E3": { "affinity": "str" },
      "E4": { "affinity": "dex" },
      "E5": { "affinity": "int" },
      "E6": { "affinity": "str" },
      "E7": { "affinity": null }
    },
    "M2-dex/int": {
      "E1": { "affinity": "dex" },
      "E2": { "affinity": "int" },
      "E3": { "affinity": "str" },
      "E4": { "affinity": "dex" },
      "E5": { "affinity": "int" },
      "E6": { "affinity": "str" },
      "E7": { "affinity": null }
    },
    "M3-dex/dex": {
      "E1": { "affinity": "dex" },
      "E2": { "affinity": "int" },
      "E3": { "affinity": "str" },
      "E4": { "affinity": "dex" },
      "E5": { "affinity": "int" },
      "E6": { "affinity": "str" },
      "E7": { "affinity": null }
    }
  }
}


- `str` vs `str` = **+1** ; `str` vs `dex` = **0** ; `str` vs `int` = **-1**
    
- `dex` vs `str` = **-1** ; `dex` vs `dex` = **+1** ; `dex` vs `int` = **0**
    
- `int` vs `str` = **0** ; `int` vs `dex` = **-1** ; `int` vs `int` = +1