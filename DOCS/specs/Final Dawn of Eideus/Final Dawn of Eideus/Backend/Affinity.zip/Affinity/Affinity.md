  

**Status:** Canonical / Internal Only**Audience:** Engine, simulation, LLM orchestration, tooling**Do Not Publish**

  

## 0. Design Intent (Authoritative)

The Affinity System exists to provide a **mathematically consistent, cross-scale state field** that:

- ticks deterministically
- couples geopolitics, economy, and social dynamics
- supports emergent behavior without exposing drivers
- provides stable bias signals for LLM tone, reasoning, and narration
- remains invariant under recursion, projection, and partial observation

Affinity is **state**, not identity. Affinity is **continuous**, not categorical. Affinity is **observable through effects**, not labels.

## 1. Core State Model

Every entity `E` in the universe hierarchy carries an **Affinity State Vector**:

Where:

- **G** = Geopolitical sway / authority pressure
- **E** = Economic flux / exchange pressure
- **S** = Social legitimacy / relational coherence

### Domain

Each component is a real number in a bounded domain:

Interpretation:

- `0.0` = baseline / neutral equilibrium
- positive = amplifying pressure
- negative = deficit / instability / erosion

> Signed values are required to model collapse, unrest, and backlash.

## 2. Entity Coverage (No Exceptions)

The following all carry `A(E)`:

- Player
- Supporting cast (AI companions, major NPCs)
- World leaders
- Governors
- Lieutenants
- Quests
- Regional locations
- Cities
- Civilizations
- Planetary objects
- Star systems
- Galaxies

  

If an entity exists in the data model, it must resolve an affinity vector.

## 3. Initialization Rules

### 3.1 Explicit Initialization

Some entities are seeded with explicit affinity vectors at creation:

- civilizations
- galaxies
- authored NPCs

These values are authoritative.

### 3.2 Inherited Initialization

If not explicitly seeded:

Parent is defined by:

- authority chain (leaders → governors → lieutenants)
- spatial ownership (city → civilization → planet)

## 4. Tick Model (Deterministic)

Affinity updates occur on discrete **simulation ticks**.

Each tick applies the following phases **in order**:

### 4.1 Decay Toward Baseline

Prevents runaway amplification.

For each component:

Where:

- `λ_*` are small decay constants
- decay may differ per scale (galaxy decays slower than city)

### 4.2 Event Injection

Discrete events apply deltas:

Examples:

- combat resolution
- quest completion/failure
- trade surge
- scandal
- decree
- narrative beat

Event deltas may affect:

- one component
- multiple components
- different magnitudes by entity role

### 4.3 Propagation (Graph-Based)

Affinity propagates through **three distinct graphs**, one per component.

#### 4.3.1 Geopolitical Graph (G)

Edges:

- authority hierarchy
- territorial adjacency
- military control relationships

Directionality:

- strong vertical (authority)
- weak lateral (borders)

#### 4.3.2 Economic Graph (E)

Edges:

- trade routes
- logistics corridors
- migration paths
- market coupling

Directionality:

- lateral and network-based
- ignores political borders unless explicitly blocked

#### 4.3.3 Social Graph (S)

Edges:

- communication channels
- institutional trust
- personal / public / professional relationships
- media and rumor paths

Directionality:

- mixed
- slower propagation
- longer memory

Propagation formula (generic):

Where:

- `i ∈ {G, E, S}`
- `N` are neighbors in the relevant graph
- `w` are normalized, bounded weights

### 4.4 Cross-Coupling (Third-Order Effects)

Components influence each other **within the same entity**.

Examples (non-exhaustive):

- Sustained high |G| dampens E locally (security friction)
- Volatile E destabilizes S (inequality, unrest)
- Strong S amplifies effective G (legitimacy, compliance)
- Collapsing S increases decay rates for G and E

Formally:

Coupling functions:

- low magnitude
- smooth (no thresholds)
- bounded

  

### 4.5 Clamping & Normalization

After all updates:

Optionally renormalize if magnitude exceeds stability envelope.

## 5. Dominant Affinity Resolution (Internal Use)

For any entity at any time, a **dominant affinity** may be derived:

This value is used for:

- LLM tone bias
- narrative framing
- UI emphasis
- quest flavor selection

This is **derived**, never stored.

## 6. LLM Integration Contract (Internal)

When an LLM reasons about, narrates, or roleplays an entity `E`:

- Inject:
- `dominant(E)`
- relative magnitudes of `(G, E, S)` (coarse, bucketed)
- Never inject raw values
- Never expose propagation logic

Mapping:

- Dominant **G** → assertive, forceful, authority-first framing
- Dominant **E** → adaptive, opportunistic, transactional framing
- Dominant **S** → procedural, legitimacy-focused, long-term framing

## 7. Recursion Across Scale (Critical)

The same affinity model applies identically at all scales.

A galaxy, a city, a quest, and a dialogue page all tick under the same rules.

Differences emerge from:

- graph topology
- decay constants
- event frequency
- coupling strength

Not from special cases.

## 8. Invariants (Must Never Break)

1. Every entity has `(G, E, S)`
2. Values are continuous and bounded
3. Tick order is deterministic
4. Decay always exists
5. Propagation graphs are distinct
6. Coupling is low-magnitude
7. Dominant affinity is derived, not assigned
8. Drivers are never exposed externally

Violating these collapses the system into either noise or a solvable toy.

## 9. Debugging & Instrumentation (Internal Only)

Allowed:

- heatmaps
- trend lines
- divergence detectors
- instability warnings

Forbidden:

- player-facing numbers
- exact thresholds
- causal explanations

Engineers may inspect vectors.Players may only experience outcomes.

## 10. Canonical Summary (Internal)

> **Affinity is a coupled vector field over the universe graph, evolving through decay, events, propagation, and cross-coupling.**

Everything else — lore, UI, diplomacy, economy, narrative tone — is a projection of this field.

If you want next, the most useful follow-on artifacts would be:

- a **reference tick pseudocode file**
- a **graph schema doc** (what edges exist at which layers)
- or a **LLM injection template** that consumes this spec without leaking internals

This spec is complete enough to implement and stable enough to live with.